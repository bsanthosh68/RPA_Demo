package com.rpa.insu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuApplication.class, args);
	}
}
